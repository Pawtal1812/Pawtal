"use client";
import React, { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { ChevronLeft, ChevronRight, Settings2, X, Plus, PawPrint } from "lucide-react";
import { saveBookingDraft, getBookingDraft } from "../bookingStore";

const groomers = [
  { id: "g1", name: "พี่หนึ่ง" },
  { id: "g2", name: "พี่ตาล" },
];

const defaultDaySlots = ["09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00", "17:00"];

function buildMonth(year, month) {
  const firstDay = new Date(year, month, 1);
  const startWeekday = firstDay.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);
  return cells;
}

const thaiMonths = ["มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"];
const thaiWeekdays = ["อา", "จ", "อ", "พ", "พฤ", "ศ", "ส"];

const mockBookedCount = { "12-09:00": 1, "12-14:00": 2, "15-11:00": 1 };
const CAPACITY_PER_SLOT = 2;

export default function DateTimeSelectPage() {
  const router = useRouter();
  const today = new Date();
  const [viewYear, setViewYear] = useState(today.getFullYear());
  const [viewMonth, setViewMonth] = useState(today.getMonth());
  const [selectedDay, setSelectedDay] = useState(today.getDate());
  const [selectedTime, setSelectedTime] = useState(null);
  const [selectedGroomer, setSelectedGroomer] = useState(groomers[0].id);
  const [shopMode, setShopMode] = useState(false);
  const [closedSlots, setClosedSlots] = useState([]);
  const [customNote, setCustomNote] = useState("");

  const cells = useMemo(() => buildMonth(viewYear, viewMonth), [viewYear, viewMonth]);

  const changeMonth = (delta) => {
    let m = viewMonth + delta;
    let y = viewYear;
    if (m < 0) { m = 11; y -= 1; }
    if (m > 11) { m = 0; y += 1; }
    setViewMonth(m);
    setViewYear(y);
    setSelectedDay(null);
    setSelectedTime(null);
  };

  const isPast = (day) => {
    if (!day) return true;
    const d = new Date(viewYear, viewMonth, day);
    const t = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    return d < t;
  };

  const slotKey = (day, time) => `${day}-${time}`;

  const toggleClosedSlot = (time) => {
    const key = slotKey(selectedDay, time);
    setClosedSlots((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  };

  const confirmBooking = () => {
    const draft = getBookingDraft();
    saveBookingDraft({
      ...draft,
      day: selectedDay,
      month: viewMonth,
      year: viewYear,
      time: selectedTime,
      groomer: selectedGroomer,
    });
    // ขั้นถัดไปในระบบจริง: ส่งข้อมูลนี้ไปที่ backend เพื่อบันทึกการจอง
    // และยิง LINE Messaging API เพื่อส่งข้อความยืนยันกลับเข้าแชท
    router.push("/confirm");
  };

  return (
    <div style={{ fontFamily: "'Nithan', 'Noto Sans Thai', sans-serif", background: "#FBF8F3", minHeight: "100vh", maxWidth: 430, margin: "0 auto", color: "#2E3A32", paddingBottom: 130, position: "relative", backgroundImage: "radial-gradient(circle at 20% 8%, #7FA88C22 0, transparent 45%), radial-gradient(circle at 85% 15%, #E8927C1c 0, transparent 40%)" }}>
      <div style={{ padding: "20px 20px 4px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 20, fontWeight: 700 }}>เลือกวันและเวลา</div>
          <div style={{ fontSize: 12.5, color: "#8A8377", marginTop: 3 }}>แตะวันที่สะดวก แล้วเลือกช่วงเวลาที่ว่าง</div>
        </div>
        <button onClick={() => setShopMode((v) => !v)} style={{ width: 38, height: 38, borderRadius: "50%", border: shopMode ? "none" : "1.5px dashed #C9C2B4", background: shopMode ? "#2E3A32" : "#FFFFFF", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }} title="โหมดร้านค้า ปรับคิวได้">
          <Settings2 size={16} color={shopMode ? "#FBF8F3" : "#8A8377"} />
        </button>
      </div>

      {shopMode && (
        <div style={{ padding: "8px 20px 0" }}>
          <div style={{ background: "#2E3A32", color: "#FBF8F3", borderRadius: 14, padding: "10px 14px", fontSize: 12, display: "flex", alignItems: "center", gap: 6 }}>
            <PawPrint size={13} color="#7FA88C" />
            โหมดร้านค้า แตะเวลาเพื่อเปิดหรือปิดคิวของวันนี้
          </div>
        </div>
      )}

      <div style={{ padding: "16px 20px 4px" }}>
        <div style={{ background: "#FFFFFF", borderRadius: 24, padding: 18, border: "1px solid #EFE9DD", position: "relative", overflow: "hidden" }}>
          <svg width="46" height="46" viewBox="0 0 46 46" style={{ position: "absolute", top: -6, right: -6, opacity: 0.5 }}>
            <circle cx="23" cy="27" r="8" fill="none" stroke="#E8927C" strokeWidth="2" />
            <circle cx="14" cy="16" r="3.2" fill="none" stroke="#E8927C" strokeWidth="2" />
            <circle cx="23" cy="12" r="3.2" fill="none" stroke="#E8927C" strokeWidth="2" />
            <circle cx="32" cy="16" r="3.2" fill="none" stroke="#E8927C" strokeWidth="2" />
          </svg>

          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
            <button onClick={() => changeMonth(-1)} style={{ border: "none", background: "#F1EEE4", borderRadius: "50%", width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <ChevronLeft size={16} color="#2E3A32" />
            </button>
            <div style={{ fontSize: 16, fontWeight: 700 }}>{thaiMonths[viewMonth]} {viewYear + 543}</div>
            <button onClick={() => changeMonth(1)} style={{ border: "none", background: "#F1EEE4", borderRadius: "50%", width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <ChevronRight size={16} color="#2E3A32" />
            </button>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 4, marginBottom: 6 }}>
            {thaiWeekdays.map((w) => (
              <div key={w} style={{ textAlign: "center", fontSize: 11.5, color: "#B8B0A2", fontWeight: 600 }}>{w}</div>
            ))}
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 4 }}>
            {cells.map((day, i) => {
              const disabled = isPast(day);
              const active = day === selectedDay && !disabled;
              return (
                <button key={i} disabled={disabled || day === null} onClick={() => { setSelectedDay(day); setSelectedTime(null); }} style={{ aspectRatio: "1", border: "none", background: "transparent", position: "relative", fontFamily: "inherit", fontSize: 13.5, fontWeight: active ? 700 : 500, color: day === null ? "transparent" : disabled ? "#D4CDBF" : "#2E3A32", cursor: disabled ? "default" : "pointer" }}>
                  {active && (
                    <svg width="34" height="34" viewBox="0 0 34 34" style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%) rotate(-4deg)" }}>
                      <path d="M17 2 C27 1, 33 8, 32 17 C33 27, 25 33, 16 32 C5 33, 1 25, 2 16 C1 6, 8 1, 17 2 Z" fill="none" stroke="#E8927C" strokeWidth="2.5" />
                    </svg>
                  )}
                  <span style={{ position: "relative", zIndex: 1 }}>{day}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div style={{ padding: "18px 20px 4px" }}>
        <div style={{ fontSize: 14.5, fontWeight: 700, marginBottom: 8 }}>เลือกช่างที่ถนัด</div>
        <div style={{ display: "flex", gap: 8 }}>
          {groomers.map((g) => {
            const active = selectedGroomer === g.id;
            return (
              <button key={g.id} onClick={() => setSelectedGroomer(g.id)} style={{ flex: 1, border: active ? "1.5px solid #7FA88C" : "1px dashed #D4CDBF", background: active ? "#7FA88C15" : "#FFFFFF", borderRadius: 16, padding: "10px 8px", fontFamily: "inherit", fontSize: 13.5, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
                🐾 {g.name}
              </button>
            );
          })}
        </div>
      </div>

      <div style={{ padding: "18px 20px 4px" }}>
        <div style={{ fontSize: 14.5, fontWeight: 700, marginBottom: 8 }}>ช่วงเวลาที่ว่าง {selectedDay ? `วันที่ ${selectedDay}` : ""}</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
          {defaultDaySlots.map((time, i) => {
            const key = slotKey(selectedDay, time);
            const closed = closedSlots.includes(key);
            const booked = mockBookedCount[key] || 0;
            const full = booked >= CAPACITY_PER_SLOT;
            const active = selectedTime === time;
            const rotate = i % 3 === 0 ? "-2deg" : i % 3 === 1 ? "1.5deg" : "-1deg";

            if (shopMode) {
              return (
                <button key={time} onClick={() => toggleClosedSlot(time)} style={{ border: closed ? "1.5px dashed #D4CDBF" : "1.5px solid #7FA88C", background: closed ? "#F1EEE4" : "#7FA88C15", borderRadius: 14, padding: "10px 14px", fontFamily: "inherit", fontSize: 13.5, fontWeight: 600, color: closed ? "#B8B0A2" : "#2E3A32", display: "flex", alignItems: "center", gap: 6, transform: `rotate(${rotate})` }}>
                  {time}
                  {closed ? <Plus size={12} /> : <X size={12} />}
                </button>
              );
            }

            return (
              <button key={time} disabled={closed || full} onClick={() => setSelectedTime(time)} style={{ border: active ? "1.5px solid #E8927C" : "1.5px solid #EFE9DD", background: active ? "#E8927C" : closed || full ? "#F1EEE4" : "#FFFFFF", borderRadius: 14, padding: "10px 16px", fontFamily: "inherit", fontSize: 13.5, fontWeight: 700, color: active ? "#FFFFFF" : closed || full ? "#C9C2B4" : "#2E3A32", transform: `rotate(${active ? "0deg" : rotate})`, transition: "transform 0.15s ease", textDecoration: closed || full ? "line-through" : "none" }}>
                {time}
              </button>
            );
          })}
        </div>
        {!shopMode && (
          <div style={{ fontSize: 11.5, color: "#B8B0A2", marginTop: 10 }}>ช่วงเวลาที่ขีดฆ่าคือเต็มแล้วหรือร้านปิดรับคิว</div>
        )}
      </div>

      {shopMode && (
        <div style={{ padding: "18px 20px 4px" }}>
          <div style={{ fontSize: 14.5, fontWeight: 700, marginBottom: 8 }}>ข้อความถึงลูกค้า</div>
          <textarea value={customNote} onChange={(e) => setCustomNote(e.target.value)} placeholder="เช่น วันนี้ร้านหยุดช่วงบ่าย หรือ คิวเช้าเต็มแล้ว" style={{ width: "100%", minHeight: 60, fontFamily: "inherit", fontSize: 13, borderRadius: 14, border: "1px solid #EFE9DD", padding: 12, resize: "vertical", color: "#2E3A32" }} />
        </div>
      )}

      {!shopMode && (
        <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 430, background: "#FFFFFF", borderTop: "1px solid #EFE9DD", padding: "14px 20px 20px", boxShadow: "0 -4px 16px rgba(46,58,50,0.06)" }}>
          <div style={{ fontSize: 12.5, color: "#8A8377", marginBottom: 10 }}>
            {selectedDay && selectedTime ? `นัดวันที่ ${selectedDay} ${thaiMonths[viewMonth]} เวลา ${selectedTime} น กับ ${groomers.find((g) => g.id === selectedGroomer)?.name}` : "เลือกวันและเวลาเพื่อดำเนินการต่อ"}
          </div>
          <button disabled={!selectedDay || !selectedTime} onClick={confirmBooking} style={{ width: "100%", background: !selectedDay || !selectedTime ? "#D4CDBF" : "#E8927C", border: "none", borderRadius: 16, padding: "16px", color: "#FFFFFF", fontSize: 15.5, fontWeight: 700, fontFamily: "inherit", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, cursor: !selectedDay || !selectedTime ? "not-allowed" : "pointer" }}>
            ยืนยันการจอง
            <ChevronRight size={18} />
          </button>
        </div>
      )}
    </div>
  );
}
