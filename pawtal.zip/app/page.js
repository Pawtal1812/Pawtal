"use client";
import { useRouter } from "next/navigation";
import { Scissors, Droplets, Sparkles, Calendar, ChevronRight, Bell, Plus } from "lucide-react";
import { useLiff } from "./useLiff";

const pets = [
  { id: 1, name: "เป้บ", breed: "Corgi", age: "1 ปี 7 เดือน", weight: "15 กก", photo: "🐕" },
];

const services = [
  { id: 1, label: "อาบน้ำ", icon: Droplets, color: "#7FA88C" },
  { id: 2, label: "ตัดขน", icon: Scissors, color: "#E8927C" },
  { id: 3, label: "สปาขน", icon: Sparkles, color: "#C9A87C" },
];

export default function HomePage() {
  const router = useRouter();
  const { profile } = useLiff();
  const activePet = pets[0];
  const displayName = profile?.displayName || "คุณมิ้นท์";

  return (
    <div
      style={{
        fontFamily: "'Nithan', 'Noto Sans Thai', sans-serif",
        background: "#FBF8F3",
        minHeight: "100vh",
        maxWidth: 430,
        margin: "0 auto",
        color: "#2E3A32",
        paddingBottom: 32,
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 20px 4px" }}>
        <div>
          <div style={{ fontSize: 13, color: "#8A8377" }}>สวัสดีตอนเช้า</div>
          <div style={{ fontSize: 22, fontWeight: 700, marginTop: 2 }}>{displayName}</div>
        </div>
        <button
          style={{ width: 40, height: 40, borderRadius: 12, border: "1px solid #D4CDBF", background: "#FFFFFF", display: "flex", alignItems: "center", justifyContent: "center" }}
          aria-label="การแจ้งเตือน"
        >
          <Bell size={18} color="#2E3A32" />
        </button>
      </div>

      <div style={{ padding: "16px 20px 8px" }}>
        <div style={{ background: "#FFFFFF", borderRadius: 20, padding: 18, display: "flex", alignItems: "center", gap: 14, border: "1px solid #EFE9DD" }}>
          <div style={{ position: "relative", flexShrink: 0 }}>
            <div style={{ width: 64, height: 64, borderRadius: "50%", background: "#F1EEE4", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, border: "2px solid #7FA88C" }}>
              {activePet.photo}
            </div>
            <div style={{ position: "absolute", bottom: -2, right: -2, width: 20, height: 20, borderRadius: "50%", background: "#E8927C", border: "2px solid #FFFFFF", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10 }}>
              🐾
            </div>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 17 }}>{activePet.name}</div>
            <div style={{ fontSize: 13, color: "#8A8377", marginTop: 2 }}>
              {activePet.breed} {activePet.age} {activePet.weight}
            </div>
          </div>
          <ChevronRight size={18} color="#B8B0A2" />
        </div>

        <button style={{ marginTop: 10, width: "100%", background: "transparent", border: "1px dashed #C9C2B4", borderRadius: 14, padding: "10px 14px", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, color: "#8A8377", fontSize: 13, fontFamily: "inherit" }}>
          <Plus size={14} />
          เพิ่มสัตว์เลี้ยงอีกตัว
        </button>
      </div>

      <div style={{ padding: "12px 20px 4px" }}>
        <div style={{ background: "#2E3A32", borderRadius: 18, padding: "16px 18px", color: "#FBF8F3", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontSize: 12, color: "#A9C2AE", marginBottom: 3 }}>นัดถัดไป</div>
            <div style={{ fontSize: 15, fontWeight: 600 }}>อาบน้ำ ตัดขน เสาร์นี้ 14:00</div>
          </div>
          <Calendar size={20} color="#7FA88C" />
        </div>
      </div>

      <div style={{ padding: "20px 20px 4px" }}>
        <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 12 }}>จองบริการ</div>
        <div style={{ display: "flex", gap: 10 }}>
          {services.map((s) => {
            const Icon = s.icon;
            return (
              <button key={s.id} onClick={() => router.push("/service")} style={{ flex: 1, background: "#FFFFFF", border: "1px solid #EFE9DD", borderRadius: 16, padding: "16px 8px", display: "flex", flexDirection: "column", alignItems: "center", gap: 8, fontFamily: "inherit" }}>
                <div style={{ width: 40, height: 40, borderRadius: 12, background: `${s.color}22`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <Icon size={18} color={s.color} />
                </div>
                <span style={{ fontSize: 12.5, fontWeight: 600 }}>{s.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div style={{ padding: "24px 20px 0" }}>
        <button
          onClick={() => router.push("/service")}
          style={{ width: "100%", background: "#E8927C", border: "none", borderRadius: 16, padding: "16px", color: "#FFFFFF", fontSize: 15.5, fontWeight: 700, fontFamily: "inherit", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
        >
          จองคิวใหม่
          <ChevronRight size={18} />
        </button>
      </div>
    </div>
  );
}
